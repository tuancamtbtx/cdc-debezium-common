create function st_buffer(inventory.geography, double precision, text) returns inventory.geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT inventory.geography(inventory.ST_Transform(inventory.ST_Buffer(inventory.ST_Transform(inventory.geometry($1), inventory._ST_BestSRID($1)), $2, $3), 4326))$$;

comment on function st_buffer(inventory.geography, double precision, text) is 'args: g1, radius_of_buffer, buffer_style_parameters - Computes a geometry covering all points within a given distance from a geometry.';

alter function st_buffer(inventory.geography, double precision, text) owner to postgres;

