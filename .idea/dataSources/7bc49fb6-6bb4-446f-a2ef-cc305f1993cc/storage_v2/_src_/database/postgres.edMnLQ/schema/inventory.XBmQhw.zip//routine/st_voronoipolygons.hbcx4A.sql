create function st_voronoipolygons(g1 inventory.geometry, tolerance double precision DEFAULT 0.0, extend_to inventory.geometry DEFAULT NULL::inventory.geometry) returns inventory.geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT inventory._ST_Voronoi(g1, extend_to, tolerance, true) $$;

comment on function st_voronoipolygons(inventory.geometry, double precision, inventory.geometry) is 'args: g1, tolerance, extend_to - Returns the cells of the Voronoi diagram of the vertices of a geometry.';

alter function st_voronoipolygons(inventory.geometry, double precision, inventory.geometry) owner to postgres;

