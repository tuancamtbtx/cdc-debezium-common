create function st_longestline(geom1 inventory.geometry, geom2 inventory.geometry) returns inventory.geometry
    immutable
    strict
    parallel safe
    cost 10000
    language sql
as
$$SELECT inventory._ST_LongestLine(inventory.ST_ConvexHull($1), inventory.ST_ConvexHull($2))$$;

comment on function st_longestline(inventory.geometry, inventory.geometry) is 'args: g1, g2 - Returns the 2D longest line between two geometries.';

alter function st_longestline(inventory.geometry, inventory.geometry) owner to postgres;

