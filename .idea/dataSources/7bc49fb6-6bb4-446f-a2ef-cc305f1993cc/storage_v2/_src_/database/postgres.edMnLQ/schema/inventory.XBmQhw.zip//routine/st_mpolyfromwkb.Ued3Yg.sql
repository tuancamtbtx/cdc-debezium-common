create function st_mpolyfromwkb(bytea) returns inventory.geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
	SELECT CASE WHEN inventory.geometrytype(inventory.ST_GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN inventory.ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

alter function st_mpolyfromwkb(bytea) owner to postgres;

