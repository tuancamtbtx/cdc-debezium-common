create function st_multilinestringfromtext(text) returns inventory.geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$SELECT inventory.ST_MLineFromText($1)$$;

alter function st_multilinestringfromtext(text) owner to postgres;

