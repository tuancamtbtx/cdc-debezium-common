create function overlaps_geog(inventory.geography, inventory.gidx) returns boolean
    immutable
    strict
    language sql
as
$$SELECT $2 OPERATOR(inventory.&&) $1;$$;

alter function overlaps_geog(inventory.geography, inventory.gidx) owner to postgres;

