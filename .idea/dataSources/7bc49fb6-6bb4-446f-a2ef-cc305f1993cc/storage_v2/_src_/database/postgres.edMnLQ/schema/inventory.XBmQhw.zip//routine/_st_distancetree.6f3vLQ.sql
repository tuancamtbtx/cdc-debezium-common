create function _st_distancetree(inventory.geography, inventory.geography) returns double precision
    immutable
    strict
    language sql
as
$$SELECT inventory._ST_DistanceTree($1, $2, 0.0, true)$$;

alter function _st_distancetree(inventory.geography, inventory.geography) owner to postgres;

