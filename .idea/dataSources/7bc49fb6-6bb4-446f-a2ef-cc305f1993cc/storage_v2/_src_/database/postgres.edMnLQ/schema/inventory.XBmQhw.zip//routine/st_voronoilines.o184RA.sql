create function st_voronoilines(g1 inventory.geometry, tolerance double precision DEFAULT 0.0, extend_to inventory.geometry DEFAULT NULL::inventory.geometry) returns inventory.geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT inventory._ST_Voronoi(g1, extend_to, tolerance, false) $$;

comment on function st_voronoilines(inventory.geometry, double precision, inventory.geometry) is 'args: g1, tolerance, extend_to - Returns the boundaries of the Voronoi diagram of the vertices of a geometry.';

alter function st_voronoilines(inventory.geometry, double precision, inventory.geometry) owner to postgres;

