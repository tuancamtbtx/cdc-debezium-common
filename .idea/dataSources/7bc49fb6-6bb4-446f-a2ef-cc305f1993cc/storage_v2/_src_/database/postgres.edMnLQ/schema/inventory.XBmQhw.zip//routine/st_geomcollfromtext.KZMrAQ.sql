create function st_geomcollfromtext(text) returns inventory.geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
	SELECT CASE
	WHEN inventory.geometrytype(inventory.ST_GeomFromText($1)) = 'GEOMETRYCOLLECTION'
	THEN inventory.ST_GeomFromText($1)
	ELSE NULL END
	$$;

alter function st_geomcollfromtext(text) owner to postgres;

