create function st_mlinefromtext(text, integer) returns inventory.geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
	SELECT CASE
	WHEN inventory.geometrytype(inventory.ST_GeomFromText($1, $2)) = 'MULTILINESTRING'
	THEN inventory.ST_GeomFromText($1,$2)
	ELSE NULL END
	$$;

alter function st_mlinefromtext(text, integer) owner to postgres;

