create function st_buffer(inventory.geography, double precision, integer) returns inventory.geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT inventory.geography(inventory.ST_Transform(inventory.ST_Buffer(inventory.ST_Transform(inventory.geometry($1), inventory._ST_BestSRID($1)), $2, $3), 4326))$$;

comment on function st_buffer(inventory.geography, double precision, integer) is 'args: g1, radius_of_buffer, num_seg_quarter_circle - Computes a geometry covering all points within a given distance from a geometry.';

alter function st_buffer(inventory.geography, double precision, integer) owner to postgres;

