create function _st_distanceuncached(inventory.geography, inventory.geography, boolean) returns double precision
    immutable
    strict
    language sql
as
$$SELECT inventory._ST_DistanceUnCached($1, $2, 0.0, $3)$$;

alter function _st_distanceuncached(inventory.geography, inventory.geography, boolean) owner to postgres;

