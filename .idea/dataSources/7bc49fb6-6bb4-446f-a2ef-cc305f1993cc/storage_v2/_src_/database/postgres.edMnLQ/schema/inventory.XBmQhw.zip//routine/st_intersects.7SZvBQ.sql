create function st_intersects(text, text) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT inventory.ST_Intersects($1::inventory.geometry, $2::inventory.geometry);  $$;

alter function st_intersects(text, text) owner to postgres;

