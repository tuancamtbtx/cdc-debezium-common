create function st_buffer(inventory.geography, double precision) returns inventory.geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT inventory.geography(inventory.ST_Transform(inventory.ST_Buffer(inventory.ST_Transform(inventory.geometry($1), inventory._ST_BestSRID($1)), $2), 4326))$$;

alter function st_buffer(inventory.geography, double precision) owner to postgres;

