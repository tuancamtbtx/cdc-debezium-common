create function st_mlinefromwkb(bytea) returns inventory.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
	SELECT CASE WHEN inventory.geometrytype(inventory.ST_GeomFromWKB($1)) = 'MULTILINESTRING'
	THEN inventory.ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

alter function st_mlinefromwkb(bytea) owner to postgres;

