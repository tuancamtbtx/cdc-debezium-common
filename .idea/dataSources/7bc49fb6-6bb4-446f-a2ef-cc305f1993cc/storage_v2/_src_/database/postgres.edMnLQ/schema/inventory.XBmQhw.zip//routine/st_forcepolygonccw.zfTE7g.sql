create function st_forcepolygonccw(inventory.geometry) returns inventory.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$ SELECT inventory.ST_Reverse(inventory.ST_ForcePolygonCW($1)) $$;

comment on function st_forcepolygonccw(inventory.geometry) is 'args: geom - Orients all exterior rings counter-clockwise and all interior rings clockwise.';

alter function st_forcepolygonccw(inventory.geometry) owner to postgres;

