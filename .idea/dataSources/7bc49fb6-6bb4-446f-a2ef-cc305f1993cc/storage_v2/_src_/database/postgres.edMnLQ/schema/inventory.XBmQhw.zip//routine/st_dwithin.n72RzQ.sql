create function st_dwithin(text, text, double precision) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT inventory.ST_DWithin($1::inventory.geometry, $2::inventory.geometry, $3);  $$;

alter function st_dwithin(text, text, double precision) owner to postgres;

