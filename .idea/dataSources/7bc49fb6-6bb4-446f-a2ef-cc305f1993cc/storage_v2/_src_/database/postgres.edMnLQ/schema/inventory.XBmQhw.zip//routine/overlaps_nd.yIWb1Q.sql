create function overlaps_nd(inventory.geometry, inventory.gidx) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$SELECT $2 OPERATOR(inventory.&&&) $1;$$;

alter function overlaps_nd(inventory.geometry, inventory.gidx) owner to postgres;

