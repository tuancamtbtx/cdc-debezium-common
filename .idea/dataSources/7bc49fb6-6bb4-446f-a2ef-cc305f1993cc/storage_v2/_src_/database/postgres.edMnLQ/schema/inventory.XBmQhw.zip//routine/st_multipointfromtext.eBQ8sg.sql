create function st_multipointfromtext(text) returns inventory.geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$SELECT inventory.ST_MPointFromText($1)$$;

alter function st_multipointfromtext(text) owner to postgres;

