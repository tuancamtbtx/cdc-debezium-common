create function st_intersection(text, text) returns inventory.geometry
    immutable
    strict
    parallel safe
    cost 10000
    language sql
as
$$ SELECT inventory.ST_Intersection($1::inventory.geometry, $2::inventory.geometry);  $$;

alter function st_intersection(text, text) owner to postgres;

