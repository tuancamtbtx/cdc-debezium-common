create function st_polyfromtext(text) returns inventory.geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
	SELECT CASE WHEN inventory.geometrytype(inventory.ST_GeomFromText($1)) = 'POLYGON'
	THEN inventory.ST_GeomFromText($1)
	ELSE NULL END
	$$;

alter function st_polyfromtext(text) owner to postgres;

