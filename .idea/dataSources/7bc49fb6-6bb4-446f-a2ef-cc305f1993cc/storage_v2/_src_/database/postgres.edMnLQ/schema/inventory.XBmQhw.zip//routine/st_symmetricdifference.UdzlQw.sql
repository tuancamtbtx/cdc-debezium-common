create function st_symmetricdifference(geom1 inventory.geometry, geom2 inventory.geometry) returns inventory.geometry
    language sql
as
$$SELECT ST_SymDifference(geom1, geom2, -1.0);$$;

alter function st_symmetricdifference(inventory.geometry, inventory.geometry) owner to postgres;

