create function st_maxdistance(geom1 inventory.geometry, geom2 inventory.geometry) returns double precision
    immutable
    strict
    parallel safe
    cost 10000
    language sql
as
$$SELECT inventory._ST_MaxDistance(inventory.ST_ConvexHull($1), inventory.ST_ConvexHull($2))$$;

comment on function st_maxdistance(inventory.geometry, inventory.geometry) is 'args: g1, g2 - Returns the 2D largest distance between two geometries in projected units.';

alter function st_maxdistance(inventory.geometry, inventory.geometry) owner to postgres;

