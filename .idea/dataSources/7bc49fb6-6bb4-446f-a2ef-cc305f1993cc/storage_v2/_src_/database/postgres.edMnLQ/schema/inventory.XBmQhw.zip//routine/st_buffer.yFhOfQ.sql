create function st_buffer(text, double precision, text) returns inventory.geometry
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT inventory.ST_Buffer($1::inventory.geometry, $2, $3);  $$;

alter function st_buffer(text, double precision, text) owner to postgres;

