create function st_intersection(inventory.geography, inventory.geography) returns inventory.geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT inventory.geography(inventory.ST_Transform(inventory.ST_Intersection(inventory.ST_Transform(inventory.geometry($1), inventory._ST_BestSRID($1, $2)), inventory.ST_Transform(inventory.geometry($2), inventory._ST_BestSRID($1, $2))), 4326))$$;

comment on function st_intersection(inventory.geography, inventory.geography) is 'args: geogA, geogB - Computes a geometry representing the shared portion of geometries A and B.';

alter function st_intersection(inventory.geography, inventory.geography) owner to postgres;

