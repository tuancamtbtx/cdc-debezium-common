create function st_distance(text, text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT inventory.ST_Distance($1::inventory.geometry, $2::inventory.geometry);  $$;

alter function st_distance(text, text) owner to postgres;

