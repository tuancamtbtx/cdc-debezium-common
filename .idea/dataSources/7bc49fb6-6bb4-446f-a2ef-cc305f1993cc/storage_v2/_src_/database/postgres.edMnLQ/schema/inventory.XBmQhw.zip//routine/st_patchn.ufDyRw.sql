create function st_patchn(inventory.geometry, integer) returns inventory.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
	SELECT CASE WHEN inventory.ST_GeometryType($1) = 'ST_PolyhedralSurface'
	THEN inventory.ST_GeometryN($1, $2)
	ELSE NULL END
	$$;

comment on function st_patchn(inventory.geometry, integer) is 'args: geomA, n - Returns the Nth geometry (face) of a PolyhedralSurface.';

alter function st_patchn(inventory.geometry, integer) owner to postgres;

