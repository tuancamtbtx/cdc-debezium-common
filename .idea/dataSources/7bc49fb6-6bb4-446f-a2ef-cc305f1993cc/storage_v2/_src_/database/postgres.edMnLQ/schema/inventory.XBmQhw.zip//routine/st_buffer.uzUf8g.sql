create function st_buffer(text, double precision) returns inventory.geometry
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT inventory.ST_Buffer($1::inventory.geometry, $2);  $$;

alter function st_buffer(text, double precision) owner to postgres;

