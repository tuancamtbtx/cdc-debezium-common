create function st_distancesphere(geom1 inventory.geometry, geom2 inventory.geometry) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$select inventory.ST_distance( inventory.geography($1), inventory.geography($2),false)$$;

alter function st_distancesphere(inventory.geometry, inventory.geometry) owner to postgres;

