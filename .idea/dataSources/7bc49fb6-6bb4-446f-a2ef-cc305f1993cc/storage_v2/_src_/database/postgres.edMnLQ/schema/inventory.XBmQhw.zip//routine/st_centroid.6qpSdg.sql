create function st_centroid(text) returns inventory.geometry
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT inventory.ST_Centroid($1::inventory.geometry);  $$;

alter function st_centroid(text) owner to postgres;

