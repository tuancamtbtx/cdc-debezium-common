create function _st_dwithinuncached(inventory.geography, inventory.geography, double precision) returns boolean
    immutable
    language sql
as
$$SELECT $1 OPERATOR(inventory.&&) inventory._ST_Expand($2,$3) AND $2 OPERATOR(inventory.&&) inventory._ST_Expand($1,$3) AND inventory._ST_DWithinUnCached($1, $2, $3, true)$$;

alter function _st_dwithinuncached(inventory.geography, inventory.geography, double precision) owner to postgres;

