create function st_multipolygonfromtext(text, integer) returns inventory.geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$SELECT inventory.ST_MPolyFromText($1, $2)$$;

alter function st_multipolygonfromtext(text, integer) owner to postgres;

