create function _st_within(geom1 inventory.geometry, geom2 inventory.geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$SELECT inventory._ST_Contains($2,$1)$$;

alter function _st_within(inventory.geometry, inventory.geometry) owner to postgres;

