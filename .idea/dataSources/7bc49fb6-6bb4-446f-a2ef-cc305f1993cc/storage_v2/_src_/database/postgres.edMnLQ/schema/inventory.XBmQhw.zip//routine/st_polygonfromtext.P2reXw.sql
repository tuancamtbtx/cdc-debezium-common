create function st_polygonfromtext(text) returns inventory.geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$SELECT inventory.ST_PolyFromText($1)$$;

alter function st_polygonfromtext(text) owner to postgres;

