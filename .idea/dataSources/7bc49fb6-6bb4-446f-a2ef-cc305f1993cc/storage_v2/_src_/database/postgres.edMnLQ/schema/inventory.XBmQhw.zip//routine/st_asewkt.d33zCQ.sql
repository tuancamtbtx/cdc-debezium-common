create function st_asewkt(text) returns text
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$ SELECT inventory.ST_AsEWKT($1::inventory.geometry);  $$;

alter function st_asewkt(text) owner to postgres;

