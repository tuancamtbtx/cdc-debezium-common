create function tuan_test.phoneNumberFormat(input STRING, code STRING, formatType STRING) returns STRING
    language js
as
    """
	return PhoneNumberFormatter.format(input, code, formatType);
"""
    options (
        library = '["gs://ts-udfs/js_libs/dist/dist.js"]'
        );

